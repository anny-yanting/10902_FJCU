# Ball_Game

Assignment for **Foundation of Artificial Intelligence**




## Copyright of 2D_simple_ball_game
```
 ****************************************************************************
 * (C) Copyright 2021 by Rung-Tzuo Liaw. All Rights Reserved.               *
 *                                                                          *
 * DISCLAIMER: The developer of this program have used his best efforts in  *
 * preparing the program. These efforts include the study, development, and *
 * testing of the program and each function in the program to ensure the    *
 * effectiveness and safety. The developer makes no warranty of any kind,   *
 * directly or indirectly, with regard to the use of the program for any    *
 * purposes, and the author shall not be liable in any event for incidental *
 * or consequential damages in connection with, or arising out of, the use  *
 * of the program.                                                          *
 ****************************************************************************
 ```
